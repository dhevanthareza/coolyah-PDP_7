"""
NAMA: DHEVAN MUHAMAD ANTHAREZA
NIM: A11.2019.12293
KELOMPOK: A11.4118
TANGGAL: 18-11-2019
"""
i = 0
data = []
while(i < 10) :
    data.append(int(input("Masukan data ke-{}: ".format(i + 1))))
    i += 1