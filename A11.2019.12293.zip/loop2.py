"""
NAMA: DHEVAN MUHAMAD ANTHAREZA
NIM: A11.2019.12293
KELOMPOK: A11.4118
TANGGAL: 18-11-2019
"""
i = 1
while(i <= 100) :
    if i % 2 == 0 :
        print(i , end=" ")
    i += 1
print("")