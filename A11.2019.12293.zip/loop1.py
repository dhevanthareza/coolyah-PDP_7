"""
NAMA: DHEVAN MUHAMAD ANTHAREZA
NIM: A11.2019.12293
KELOMPOK: A11.4118
TANGGAL: 18-11-2019
"""
loop1 = 1
loop2 = 50
while True :
    print("loop 1", loop1)
    print("loop 2", loop2)
    print("selisih", abs(loop1-loop2))
    if(loop1 == 50) :
        break
    loop1 += 1
    loop2 -= 1