"""
NAMA: DHEVAN MUHAMAD ANTHAREZA
NIM: A11.2019.12293
KELOMPOK: A11.4118
TANGGAL: 18-11-2019
"""
i = 0
while (i <= 100) :
    if(str(i).find("1") != -1) :
        print(i, end=" ")
    i += 1
print(" ")